/* constants used by all code  */

#define MAX_NUM_GeneLen 140000
#define MAX_NUM_AlphaNo 200
#define MAX_NUM_RepNo 100
#define MAX_NUM_IsoNo 200

#define ALOW 0.000001




