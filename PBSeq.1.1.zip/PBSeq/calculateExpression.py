#! /usr/bin/env python 
from __future__ import division  


import os 
import sys, getopt
import pp
import numpy as np
import example
import createAlignmentFolder


def usage():
  print "Usage:"
  print "    calculateExpression -a Annotation_Name  -i TargetGene "
  print "options:"
  print '   -a/--Annotation        the abbreviative name is same as the outputName of preprocessAnnotation, eg:ensGene'
  print '   -i/--InputGene         input objective gene'
  print '   -l/--log               the natural logarithmic expression to detecting different expressed genes or isoforms'              
  print '   -h/--help              display this help and exit'
  print '   -v/--version           output version information and exit\n'
  sys.exit(1)

def error(n):
  if n==1:
    print "Error: need input the correct parameters:  -a <string> OR  -a <string> -i <file> \n" 
  if n==2:
    print "Error: need input the complete parameters:  -a <string> OR  -a <string> -i <file>\n"


try:
    opts, args = getopt.getopt(sys.argv[1:], "hvla:i:", ["help","version", "Annotation","InputGene","log"])
except getopt.GetoptError:
    error(1)
    usage()
    sys.exit()


targetGene = 'default'
input_name = 'default'
log_flag =0

for op, value in opts:
    if op in ["-a","--Annotation"]:
        input_name = value
    elif op in ['-i','--InputGene']:
      targetGene = value
    elif op in ['-l','--log']:
      log_flag = 1
    elif op in ["-v","--version"]:
        print 'The version of PBSeq is v0.1_alpha.'
        sys.exit()
    elif op in ["-h","--help"]:
        usage()        
        sys.exit()

if targetGene == 'default':                            # now, the targetGene will set 'default'
  currentPath = os.getcwd()
  targetDir = os.path.join(currentPath,'Annotation')
  targetGene = os.path.join(targetDir,input_name)
  targetGeneFile = targetGene+'.Gene.Info'  
else:
  targetGeneFile = targetGene

parametersList = [input_name,targetGeneFile]

if 'default' in parametersList:
    error(2)
    usage()
    sys.exit()
else:
    pass


f= open(targetGeneFile,'r')
geneNameList = []
isoNoList = []
dictTransName = {}
for line in f:
    line = line.rstrip()
    line = line.split('\t')
    geneName = line[0]
    isoNo = int(line[1])
    transName = line[3:]

    geneNameList.append(geneName)
    isoNoList.append(isoNo)
    dictTransName[geneName]=transName
f.close()





currentPath = os.getcwd()
modelDataPath = os.path.join(currentPath,'Model.Data')
tempDataPath = os.path.join(currentPath,'Model.Temp')
ResultPath = os.path.join(currentPath,'PBSeq.Results')

f = open(os.path.join(modelDataPath,'Alignment.Read.No'),'r')
Data = f.readline()
f.close()

Data = Data.rstrip()
AlignmentReadNo = Data.split('\t')
repNo = len(AlignmentReadNo)
NormalizeConst = [0 for i in range(repNo)]
for i in range(repNo):
  NormalizeConst[i] = int(AlignmentReadNo[i])/1000000




geneNo = len(geneNameList)
isoNoSum = sum(isoNoList)

geneMean = np.zeros((geneNo,repNo))
geneVar = np.zeros((geneNo,repNo))
transMean = np.zeros((isoNoSum,repNo))
transVar = np.zeros((isoNoSum,repNo))

isoNoIndex = 0
for index in xrange(geneNo):
    geneName = geneNameList[index]
    isoNo = int(isoNoList[index])
    transName = dictTransName[geneName]

    geneDataPath = os.path.join(modelDataPath,'Gene.Data')
    geneDataFile = os.path.join(geneDataPath,geneName)

    geneMapPath = os.path.join(modelDataPath,'Gene.Map')
    geneMapFile = os.path.join(geneMapPath,geneName)

    geneBiasPath = os.path.join(modelDataPath,'Gene.Bias')
    geneBiasFile = os.path.join(geneBiasPath,geneName)

    f = open(geneDataFile,'r')
    Data = [line.rstrip()  for line in f.readlines()]
    f.close()

    # print geneDataFile,geneMapFile,geneBiasFile

    geneLen = len(Data)
    # print geneName,isoNo,geneLen,repNo,index
    # print geneName



    for repInd in xrange(repNo):
      normConst=NormalizeConst[repInd]
      example.getData(geneDataFile,geneMapFile,geneBiasFile,isoNo,geneLen,repNo,repInd,normConst)
      expression=example.calparameters(isoNo)

      geneMean[index,repInd]= expression[0]
      geneVar[index,repInd] = expression[1]
      for i in xrange(isoNo):
        transMean[isoNoIndex+i,repInd]=expression[2+i]
        transVar[isoNoIndex+i,repInd]= expression[2+isoNo+i]
    isoNoIndex = isoNoIndex+isoNo



f_geneMean = open(os.path.join(ResultPath,'gene.mean'),'w')
f_geneSd = open(os.path.join(ResultPath,'gene.standard.deviation'),'w')
f_transMean = open(os.path.join(ResultPath,'isoform.mean'),'w')
f_transSd = open(os.path.join(ResultPath,'isoform.standard.deviation'),'w')

isoNoIndex = 0
for i in xrange(geneNo):
  geneName = geneNameList[i]
  f_geneMean.write(geneName+'\t')
  f_geneSd.write(geneName+'\t')
  for j in range(repNo):
    f_geneMean.write(str(round(geneMean[i,j],6))+'\t')
    f_geneSd.write(str(round(np.sqrt(geneVar[i,j]),6))+'\t')
  f_geneMean.write('\n')
  f_geneSd.write('\n')

  isoNo = isoNoList[i]
  isoGeneName = dictTransName[geneName]
  for j in range(isoNo):
    isoName = isoGeneName[j]
    f_transMean.write(isoName+'\t')
    f_transSd.write(isoName+'\t')
    for k in range(repNo):
      f_transMean.write(str(round(transMean[isoNoIndex+j,k],6))+'\t')
      f_transSd.write(str(round(np.sqrt(transVar[isoNoIndex+j,k]),6))+'\t')
    f_transMean.write('\n')
    f_transSd.write('\n')
  isoNoIndex=isoNoIndex+isoNo

f_geneMean.close()
f_transSd.close()
f_transMean.close()
f_transSd.close()


SamplingNo = 20000
const = np.log(2)
isoNoIndex=0
if log_flag==1:
  f_genelogMean = open(os.path.join(ResultPath,'gene.mean.log'),'w')
  f_genelogSd = open(os.path.join(ResultPath,'gene.standard.deviation.log'),'w')
  f_translogMean = open(os.path.join(ResultPath,'isoform.mean.log'),'w')
  f_translogSd = open(os.path.join(ResultPath,'isoform.standard.deviation.log'),'w')

  for i in xrange(geneNo):
    geneName=geneNameList[i]
    f_genelogMean.write(geneName+'\t')
    f_genelogSd.write(geneName+'\t')
    for j in range(repNo):
      np.random.seed(i)
      m = geneMean[i,j]
      sd = np.sqrt(geneVar[i,j])
      samples = np.random.normal(m,sd,SamplingNo)
      samplesPos = samples[samples>0]
      samplesPosLog = np.log(samplesPos)
      geneLogMean = np.mean(samplesPosLog)/const
      geneLogSd = np.std(samplesPosLog)/const

      f_genelogMean.write(str(round(geneLogMean,6))+'\t')
      f_genelogSd.write(str(round(geneLogSd,6))+'\t')
    f_genelogMean.write('\n')
    f_genelogSd.write('\n')


    isoNo = isoNoList[i]
    isoGeneName = dictTransName[geneName]
    for j in range(isoNo):
      isoName = isoGeneName[j]
      f_translogMean.write(isoName+'\t')
      f_translogSd.write(isoName+'\t')
      for k in range(repNo):
        np.random.seed(i)
        m = transMean[isoNoIndex+j,k]
        sd = np.sqrt(transVar[isoNoIndex+j,k])
        samples = np.random.normal(m,sd,SamplingNo)
        samplesPos = samples[samples>0]
        samplesPosLog = np.log(samplesPos)
        transLogMean = np.mean(samplesPosLog)/const
        transLogSd = np.std(samplesPosLog)/const

        f_translogMean.write(str(round(transLogMean,6))+'\t')
        f_translogSd.write(str(round(transLogSd,6))+'\t')
      f_translogMean.write('\n')
      f_translogSd.write('\n')
    isoNoIndex=isoNoIndex+isoNo

  f_genelogMean.close()
  f_genelogSd.close()
  f_translogMean.close()
  f_translogSd.close()
else:
  pass


createAlignmentFolder.deleteDataFolder()
