#include<Python.h>
#include <malloc.h>

double* calparameters(int isoNo);

//导出函数
PyObject *wrap_getgenedata(PyObject* self,PyObject* args)
{	
	char *geneDataFile;
	char *geneMapFile;
	char *geneBiasFile;
	int isoNo;
	int geneLen;
	int repNo;
	int repInd;
	double normConst;
	if(!PyArg_ParseTuple(args,"sssiiiid",&geneDataFile,&geneMapFile,&geneBiasFile,&isoNo,&geneLen,&repNo,&repInd,&normConst))
	  return NULL;
	getData(geneDataFile,geneMapFile,geneBiasFile,isoNo,geneLen,repNo,repInd,normConst);
	Py_INCREF(Py_None);
	return Py_None;
}




PyObject *wrap_calparameters(PyObject* self,PyObject* args)
{
	int i,isoNo;
	char *resultPath;
	double *a;



	if(!PyArg_ParseTuple(args,"i",&isoNo))
	  return NULL;

	PyObject* pList = PyList_New(2*isoNo+2);
	assert(PyList_Check(pList));


	a=calparameters(isoNo);

	for(i=0;i<2*isoNo+2;i++){
		PyList_SetItem(pList,i,Py_BuildValue("d",a[i]));
	    // printf("%lf\t%lf\n",temp[i],a[i] );
	}
	free(a);


	return pList;
}



//方法列表
static PyMethodDef exampleMethods[]=
{
	{"getData",wrap_getgenedata,METH_VARARGS,"Get model data! "},
	{"calparameters",wrap_calparameters,METH_VARARGS,"Calculate Expression! "},


	{NULL,NULL}
};
//初始化函数
void initexample()
{
	PyObject* m;
	m=Py_InitModule("example",exampleMethods);
}
