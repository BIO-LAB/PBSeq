#!/usr/bin/env python


import os, os.path
import sys, getopt
import createAlignmentFolder
import covertAlignment
import calculateBias
import generateData

def usage():
  print "Usage:"
  print "    preprocessAlignment -t Annotation_Type -d AlignmentFiles  -o Annotation_Name -i Input_Gene "
  print "options:"
  print "   -t/--Type              supported four types: refGene, ensGene, knownGene and Ensembl"
  print '   -d/--AlignmentFiles    input one or a list of alignment files from Bowtie, eg: SRRXXX.output'
  print '   -a/--Annotation        the abbreviative name is same as the outputName of preprocessAnnotation, eg:ensGene'
  print '   -i/--InputGene         input gene'
  print '   -h/--help              display this help and exit'
  print '   -v/--version           output version information and exit\n'
  sys.exit(1)

def error(n):
  if n==1:
    usage()
		# print "Error: need input the correct parameters:  -t <string> -d <file or files>  -a <string> OR -t <string> -d <file or files>  -a <string> -i <file> \n"   
  if n==2:
    usage()
		# print "Error: need input the complete parameters: -t <string> -d <file or files>  -a <string> OR -t <string> -d <file or files>  -a <string> -i <file>\n"



 
try:
    opts, args = getopt.getopt(sys.argv[1:], "hva:d:i:t:", ["help","version", "Annotation","AlignmentFiles","InputGene","Type"])
except getopt.GetoptError:
    error(1)
    usage()
    sys.exit()


targetGene = 'default'
input_name = 'default'
alignment_paths = 'default'

for op, value in opts:
    if op in ["-a","--Annotation"]:
        input_name = value
    elif op in ["-d","--AlignmentFiles"]:
        alignment_paths = value
    elif op in ['-i','--InputGene']:
    	targetGene = value
    elif op in ['-t','--Type']:
      annotation_type = value
    elif op in ["-v","--version"]:
        print 'The version of PBSeq is v0.2_beta.'
        sys.exit()
    elif op in ["-h","--help"]:
        usage()        
        sys.exit()


if targetGene == 'default':                            # now, the targetGene will set 'default'
	currentDir = os.getcwd()
	targetDir = os.path.join(currentDir,'Annotation')
	targetGene = os.path.join(targetDir,input_name)
	targetGeneFile = targetGene+'.Gene.Info'	
else:
	targetGeneFile = targetGene

parametersList = [alignment_paths,input_name,targetGeneFile]

if 'default' in parametersList:
    error(2)
    usage()
    sys.exit()
else:
    pass


alignment_paths = alignment_paths.rstrip()
alignment_paths = alignment_paths.split(',')
Alignment_Names = []
for i in xrange(len(alignment_paths)):
	alignment_path = alignment_paths[i]
	alignment_path = alignment_path.split('/')
	alignfile = alignment_path[-1]

	alignfile = alignfile.split('.')
	alignfile = alignfile[0:len(alignfile)-1]
	algnName = alignfile[0]
	for j in xrange(1,len(alignfile)):
		algnName = algnName+'.'+alignfile[j]
	Alignment_Names.append(algnName)
# print Alignment_Names

print 'createFolder...'
createAlignmentFolder.createFolder(Alignment_Names)


print 'Coverting Alignment ......'
covertAlignment.covertAlignment(annotation_type,alignment_paths,Alignment_Names,input_name)

print 'Calculating Bias Weight ......'
calculateBias.calculateBias(Alignment_Names,input_name,targetGeneFile)

print 'Generating Model Data ......'
generateData.generateData(Alignment_Names,input_name,targetGeneFile)


print 'Done.'
createAlignmentFolder.deleteTempFolder()
