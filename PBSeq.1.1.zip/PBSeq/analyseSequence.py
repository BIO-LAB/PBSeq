#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, os.path
# 
def AnalyseSequence(AnnotationType,SequenceFile,OutputFile,OutputDir):
	Dict = {}
	f = open(os.path.join(OutputDir,OutputFile+'.Gene.Info'),'r')
	for line in f:
	    line = line.rstrip()
	    line = line.split('\t') 
	    gene = line[0]
	    isono = int(line[1])
	    isoname = line[3:]
	    for i in xrange(isono):
	        iso = isoname[i]
	        Dict[iso] = gene
	f.close()

	f= open(SequenceFile,'r')
	transSeqFile = os.path.join(OutputDir,OutputFile+'.Transcript.Sequence.fa')
	fo = open(transSeqFile,'w')    # maybe create a dict instead to .fa file
	lineNo = 1
	for line in f:
	    line =line.rstrip()
	    line = line.split(' ')
	    if len(line)>1:
	        if AnnotationType in ["knownGene","ensGene"]:
		        trans = line[0].split('_')
		        trans = trans[2]
	        elif AnnotationType in ["refGene"]:
		        trans = line[0].split('_')
		        trans = trans[2]+'_'+trans[3]
	        elif AnnotationType in ["Ensembl"]:
		        trans = line[0].split(' ')
		        trans = trans[0].split('>')
		        trans = trans[1].rstrip()
	        else:
		    	pass
	        # print trans

	        if trans in Dict:
	            if lineNo ==1:
	               lineNo = 2
	            else:
	               fo.write('\n')
	            gene = Dict[trans]
	            fo.write(trans+'\t'+gene+'\t')
	        else:
	            pass
	    else:
	        if trans in Dict:
	           fo.write(line[0])
	        else:
	           pass
	f.close()
	fo.close()
	# print len(Dict)


	f_in = open(transSeqFile,'r')
	Dict_Seq = {}
	for line in f_in:
	    line = line.rstrip()
	    line = line.split('\t')
	    Trans  = line[0].strip()
	    TransSeq = line[2]
	    Dict_Seq[Trans] = TransSeq

	f_in.close()

	# print len(Dict_Seq)



	f_in = open(os.path.join(OutputDir,OutputFile+'.Exon.Split'),'r')
	Data = [line.strip() for line in f_in.readlines()];
	Data = [line.split('\t') for line in Data];
	f_in.close()

	Dict_Gene = {}
	Dict_Iso = {}

	i=0
	while i<len(Data):
	     Gene = Data[i][0].rstrip()
	     IsoNo = int(Data[i][1])
	     ExonNo = int(Data[i][2])
	     ExonInd = Data[i][3].split(',')
	     ExonLen = Data[i][4].split(',')
	     Dict_Gene[Gene] = IsoNo,ExonNo,ExonInd,ExonLen
	     i=i+1
	     for j in range(IsoNo):
	         Iso = Data[i+j][1]
	         ExonNo = int(Data[i+j][2])
	         ExonInd = Data[i+j][3].split(',')
	         ExonLen = Data[i+j][4].split(',')
	         Dict_Iso[Iso] = ExonNo,ExonInd,ExonLen
	     i=i+IsoNo    


	f_in = open(os.path.join(OutputDir,OutputFile+'.Gene.Info'),'r')
	f_out = open(os.path.join(OutputDir,OutputFile+'.Gene.Sequence.fa'),'w')
	f_out1 = open(os.path.join(OutputDir,OutputFile+'.Gene.SingleTrans.Sequence.fa'),'w')

	for line in f_in:
	    line = line.rstrip()
	    line = line.split('\t')
	    Gene = line[0].rstrip()
	    IsoNo = int(line[1])
	    GeneLen = int(line[2])
	    IsoList = line[3:]

	    if IsoNo ==1:
	       Iso = IsoList[0].strip()
	       IsoSeq = Dict_Seq[Iso]     
	       f_out.write(Gene+'\t'+str(IsoNo)+'\t'+str(len(IsoSeq))+'\t'+str(IsoSeq)+'\n')
	       f_out1.write(Gene+'\t'+IsoList[0]+'\t'+str(len(IsoSeq))+'\t'+str(IsoSeq)+'\n')

	    else:
	       GeneInfo =  Dict_Gene[Gene]
	       ExonNoG = GeneInfo[1]
	       ExonInd = GeneInfo[2]
	       ExonLen = GeneInfo[3]

	       SeqList = [[[]  for i in range(ExonNoG)] for i in range(IsoNo)]

	       for i in range(IsoNo):
	           Iso = IsoList[i].strip()
	           ExonNo,ExonInd,ExonLen =  Dict_Iso[Iso]
	           IsoSeq = Dict_Seq[Iso]
	           ExonStart = 0
	           for j in range(ExonNo):
	               SeqInd = int(ExonInd[j])
	               ExonEnd = int(ExonLen[j])
	               ExonSeq = IsoSeq[ExonStart:ExonEnd]
	               SeqList[i][SeqInd-1] = ExonSeq
	               ExonStart = ExonEnd                                                           

	       GeneSeq = ''
	       for i in range(ExonNoG):
	           for j in range(IsoNo):
	               if len(SeqList[j][i]) != 0:
	                   GeneSeq = GeneSeq+str(SeqList[j][i])
	                   break

	       f_out.write(Gene+'\t'+str(IsoNo)+'\t'+str(len(GeneSeq))+'\t'+str(GeneSeq)+'\n')

	f_out.close()
	f_out1.close()

	os.remove(transSeqFile)





















