#! /bin/env bash 
 gcc  -c -lm -fPIC -I/usr/include/python2.7 donlp2.c newx.c calculateExpression.c user_eval.c wrap.c
 gcc  -shared -fPIC -o example.so donlp2.o newx.o calculateExpression.o user_eval.o wrap.o
