#include "constants.h"

typedef struct 
{
	int GeneLen;
	int AlphaNo;
	int IsoNo;
	int RepNo;
	int RepInd;
	double NormConst;
	

	double GeneMap[MAX_NUM_GeneLen][MAX_NUM_IsoNo];	
  	double GeneData[MAX_NUM_GeneLen]; 
 	double GeneBias[MAX_NUM_GeneLen];  
    
    double parameters[MAX_NUM_AlphaNo]; 
    double output[2*MAX_NUM_IsoNo];
 
			
} expparam;


// double digamma (double x);	
// void poga_allocatemem();
// void poga_freemem();
// void getData(char *GeneDataP,char *GeneMapP,char *GeneLenP,int IsoNo,int ExonNo,int Rep);
double* calparameters(int isoNo);



