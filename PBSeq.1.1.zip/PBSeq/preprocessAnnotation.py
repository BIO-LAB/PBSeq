#!/usr/bin/env python


import os, os.path
import sys, getopt
import analyseAnnotation
import analyseSequence


def usage():
  print "Usage:"
  print "    preprocessAnnotation -t Annotation_Type  -a Annotation_File  -s Sequence_File -o Annotation_Name"
  print ''
  print "options:"
  print "   -t/--Type              supported four types: refGene, ensGene, knownGene and Ensembl"
  print '   -a/--AnnotationFile    input the reference annotation file, eg: ensGene.txt'
  print '   -s/--SequenceFile      input the corresponding reference transcript sequence file, : eg: ensGene.fasta'
  print '   -o/--OutputName        the abbreviative name of output file, eg: ensGene '
  print '   -h/--help              display this help and exit'
  print '   -v/--version           output version information and exit\n'

  print "Example:"
  print "    Supported four types: refGene, ensGene, knownGene and Ensembl"
  print "    preprocessAnnotation.py -t refGene -a refGene.txt -s refGene.fasta -o refGene"
  print "    preprocessAnnotation.py -t ensGene -a ensGene.txt -s ensGene.fasta -o ensGene"
  print "    preprocessAnnotation.py -t knownGene -a knownGene.txt,knownIsoforms.txt -s knownGene.fasta -o knownGene"
  print "    preprocessAnnotation.py -t Ensembl -a Homo_sapiens.GRCh37.67.gtf -s Homo_sapiens.GRCh37.67.cdna.all.fa -o Ensembl"



  sys.exit(1)


def error():
    usage()
    # print "Error: need input the correct parameters: -t <string> -a <file> -o <string> -s <file>\n" 

try:
    opts, args = getopt.getopt(sys.argv[1:], "hvt:a:o:s:", ["help","version","Type","AnnotationFile","OutputName","SequenceFile"])
except getopt.GetoptError:
    error()
    usage()
    sys.exit()


for op, value in opts:
    if op in ["-a","--AnnotationFile"]:
        annotation_file = value
    elif op in ["-t","--Type"]:
        annotation_type = value
    elif op in ["-s","--SequenceFile"]:
        sequence_file = value
    elif op in ["-o","--OutputName"]:
        output_name = value
    elif op in ["-v","--version"]:
        print 'The version of PBSeq is v0.1_beta.'
        sys.exit()
    elif op in ["-h","--help"]:
        usage()        
        sys.exit()

if len(opts)<4:
    error()
    usage()
    sys.exit()
else:
    pass

#---------------------------------------------#
targetDir = os.getcwd()
targetFolder = os.path.join(targetDir,'Annotation')
if os.path.exists(targetFolder):
    pass
else:
    os.mkdir(targetFolder)
outputDir = targetFolder


print "Pre-processing the Annotation Files ...... "
analyseAnnotation.CovertAnnotation(annotation_type,annotation_file,sequence_file,output_name,outputDir)
analyseAnnotation.AnalyseAnnotation(annotation_file,output_name,outputDir)

print "Pre-processing the Sequence Files ...... "
analyseSequence.AnalyseSequence(annotation_type,sequence_file,output_name,outputDir)


print 'Done.'