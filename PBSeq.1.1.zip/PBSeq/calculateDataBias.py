#! /usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import division

import os
import numpy as np



LenSets = [[0,1340],[1341,2101],[2102,2982],[2983,4383],[4384,float('inf')]]
DictBase = {'A':1,'G':2,'C':3,'T':4}
BaseList = ['A','G','C','T']
Par1List = [0,1,2,3,19,20]
Par2List = [4,5,6,17,18]
Par3List = [7,8,9,10,11,12,13,14,15,16]

def PositionBias(ValidGene,Dict_Seq,Dict_Vect,OutputDir,ReadLen):
        LenSets = [[0,1340],[1341,2101],[2102,2982],[2983,4383],[4384,float('inf')]]
   
        Dict_Bias = {}
        Dict_Null = {}
        for i in range(1,101):
            Dict_Bias[i] =0
            Dict_Null[i] =0      
        k=0
        for i in range(len(ValidGene)):
            Gene = ValidGene[i]
            Trans,Gene,Len,Seq = Dict_Seq[Gene]
            Count = Dict_Vect[Gene]
        #    AvgCount = sum(Count)/20
            k=k+1
            
            LenEff = int(Len)-ReadLen+1
            if LenEff <20:
               # print Gene,LenEff,sum(Count)       
               continue

            for Ind in range(5):
                Start = LenSets[Ind][0]
                End = LenSets[Ind][1]
                if LenEff<=End and LenEff >Start: 
                   break
                else:
                   pass


            BinLen = int(LenEff/20);
            for i in range(20):
                Start = BinLen*i
                End = BinLen*(i+1)
                BinCount = sum(Count[Start:End])
                Dict_Bias[20*Ind+1+i] = Dict_Bias[20*Ind+1+i]+BinCount
                Dict_Null[20*Ind+1+i] = Dict_Null[20*Ind+1+i]+sum(Count)*(End-Start)/LenEff         


        fo = open(OutputDir+'.PosBias','w')
        for i in range(5):
            for j in range(20):
                PosBias = Dict_Bias[20*i+j+1]
                PosNull = Dict_Null[20*i+j+1]
                fo.write(str(i+1)+'\t'+str(j+1)+'\t'+str(int(round(PosBias,3)))+'\t'+str(int(round(PosNull,3)))+'\n')
        fo.close()




def SequenceBias(ValidGene,Dict_Seq,Dict_Vect,OutputDir,ReadLen):
      DictBase = {'A':1,'G':2,'C':3,'T':4}
      BaseList = ['A','G','C','T']
      Par1List = [0,1,2,3,19,20]
      Par2List = [4,5,6,17,18]
      Par3List = [7,8,9,10,11,12,13,14,15,16]

      ParGroup = []
      for i in range(4):
          BaseST= BaseList[i]
          ParGroup.append(BaseST)
          
      for i in range(4):
          BaseST = BaseList[i]
          for j in range(4):
              BaseND = BaseList[j]
              ParGroup.append(BaseST+BaseND)

      for i in range(4):
           BaseST = BaseList[i]
           for j in range(4):
                BaseND = BaseList[j]
                for k in range(4):
                         BaseRD = BaseList[k]
                         ParGroup.append(BaseST+BaseND+BaseRD)

      Dict_Bias = {}
      Dict_Null = {}
      for Ind in range(21):
          if Ind in Par1List:
             for i in range(4):
                 BaseST= BaseList[i]
                 IndST = DictBase[BaseST]
                 BaseGroup = str(Ind)+'.'+BaseST
                 Dict_Bias[BaseGroup] = 0
                 Dict_Null[BaseGroup] = 0
             
          elif Ind in Par2List:
             for i in range(4):
                 BaseST = BaseList[i]
                 for j in range(4):
                     BaseND = BaseList[j]
                     IndND = DictBase[BaseND]
                     BaseGroup = str(Ind)+'.'+BaseST+BaseND 
                     Dict_Bias[BaseGroup] = 0
                     Dict_Null[BaseGroup] = 0
          else:   
             for i in range(4):
                 BaseST = BaseList[i]
                 for j in range(4):
                     BaseND = BaseList[j]
                     for k in range(4):
                         BaseRD = BaseList[k]
                         IndRD = DictBase[BaseRD]
                         BaseGroup = str(Ind)+'.'+BaseST+BaseND+BaseRD
                         Dict_Bias[BaseGroup] = 0
                         Dict_Null[BaseGroup] = 0

      k=0
      for i in range(len(ValidGene)):
          Gene = ValidGene[i]
          k=k+1

          Trans,Gene,Len,Seq = Dict_Seq[Gene]
          Count = Dict_Vect[Gene]
          AvgCount = sum(Count)/(int(Len)-ReadLen+1)
          #AvgCount = 1

          for i in range(8,int(Len)-ReadLen+1):
              SubSeq = Seq[i-8:i+13]
              SubCount = Count[i]
              for j in range(21):
                   if j in Par1List:
                      Base = SubSeq[j]
                      BaseInd = str(j)+'.'+Base
                      Dict_Bias[BaseInd] = Dict_Bias[BaseInd]+SubCount
                      Dict_Null[BaseInd] = Dict_Null[BaseInd]+AvgCount
                   elif j in Par2List:
                      Base = SubSeq[j]
                      BaseParent = SubSeq[j-1]
                      BaseInd = str(j)+'.'+Base+BaseParent
                      Dict_Bias[BaseInd] = Dict_Bias[BaseInd]+SubCount
                      Dict_Null[BaseInd] = Dict_Null[BaseInd]+AvgCount
                   else:
                      Base = SubSeq[j]
                      BaseParent = SubSeq[j-1]
                      BaseGrandParent = SubSeq[j-2]
                      BaseInd = str(j)+'.'+Base+BaseParent+BaseGrandParent
                      Dict_Bias[BaseInd] = Dict_Bias[BaseInd]+SubCount
                      Dict_Null[BaseInd] = Dict_Null[BaseInd]+AvgCount
              


      fo = open(OutputDir+'.SeqBias','w')

      for i in range(21):
          for j in range(len(ParGroup)):
              Ind = str(i)+'.'+ParGroup[j]
              if Ind in Dict_Bias:
                  SeqBias = Dict_Bias[Ind]
                  SeqNull = Dict_Null[Ind]
                  fo.write(str(i-8)+'\t'+ParGroup[j]+'\t'+str(int(SeqBias))+'\t'+str(int(SeqNull))+'\n')
              else:
                  pass


      fo.close()


def PosBiasProb(InputData):
        BiasMat = np.zeros(100)
        NullMat = np.zeros(100)
        f=open(InputData,'r')
        k=0
        for line in f:
            line = line.rstrip()
            line = line.split('\t')
            data = line[2:]
            BiasMat[k] = float(data[0])
            NullMat[k] = float(data[1])
            k = k+1
        f.close()
        RateMat = BiasMat/NullMat
        return RateMat


def SeqBiasProb(InputData,Norm=['Base','None']):            
        Dict_Bias = {}
        Dict_Null = {}
        for i in range(-8,13):
            Dict_Bias[i] = 0
            Dict_Null[i] = 0
        RateMat = np.zeros(744)

        f = open(InputData,'r')
        for line in f:
            line = line.rstrip()
            line = line.split('\t')
            Ind = int(line[0])
            Bias = line[2]
            Null = line[3]
            Dict_Bias[Ind] = Dict_Bias[Ind] + int(Bias)
            Dict_Null[Ind] = Dict_Null[Ind] + int(Null)
        f.close()

        f = open(InputData,'r')
        k =0 
        for line in f:
            line = line.rstrip()
            line = line.split('\t')
            Ind = int(line[0])
            BaseGroup = line[1]
            Bias = int(line[2])
            Null = int(line[3])    

            BiasTotal = Dict_Bias[Ind]
            NullTotal = Dict_Null[Ind]

            if Norm =='Base':
                BiasProb = Bias/BiasTotal
                NullProb = Null/NullTotal
                RateMat[k] = BiasProb/NullProb
            else:
                RateMat[k] =  Bias/Null
            k=k+1
        f.close()
        return RateMat        




def ExtractGeneBias(Dict_GeneSeq,Dict_PosBias,Dict_SeqBias,ReadLen,Lane):

    LenSets = [[0,1340],[1341,2101],[2102,2982],[2983,4383],[4384,float('inf')]]
    DictBase = {'A':1,'G':2,'C':3,'T':4}
    BaseList = ['A','G','C','T']
    Par1List = [0,1,2,3,19,20]
    Par2List = [4,5,6,17,18]
    Par3List = [7,8,9,10,11,12,13,14,15,16]


    for geneName, geneSeq in Dict_GeneSeq.iteritems():
        geneLen = len(geneSeq)

        EffLen = int(geneLen)-ReadLen+1
        if EffLen >=50:
          Len = EffLen
          PosBias = np.zeros((Len,Lane))
          
          for i in range(5):
              if Len <= LenSets[i][1] and Len>=LenSets[i][0]:
                 PosInd = i
                 break
          Bin = int(Len/20)    

          for i in range(19):
              Start = Bin*i
              End = Bin*(i+1) 
              Ind = str(PosInd+1)+'.'+str(i+1)      
              PosProb = Dict_PosBias[Ind]
              for j in range(Lane):
                  PosBias[Start:End,j] = float(PosProb[j])

          Ind = str(PosInd+1)+'.'+str(20)  
          PosProb = Dict_PosBias[Ind]
          # print PosProb
          Start = Bin*19
          for j in range(Lane):
              PosBias[Start:Len,j] = float(PosProb[j])
          # print PosBias[-1,:]
          

          SeqBias = np.ones(Len*Lane).reshape(Len,Lane)

          for i in range(8,Len):
              SubSeq = geneSeq[i-8:i+13]
              SeqProd = 1
              for j in range(len(SubSeq)):            
                  if j in Par1List:
                     Base = SubSeq[j]
                  elif j in Par2List:
                     Base = SubSeq[j-1:j+1]
                     Base = Base[::-1]
                  else:
                     Base = SubSeq[j-2:j+1]
                     Base = Base[::-1]

                  BaseInd = str(j-8)+'.'+Base
                  ProbList = Dict_SeqBias[BaseInd]
                  for k in range(Lane):
                      SeqBias[i,k] = SeqBias[i,k]*float(ProbList[k])

          TotalBias = PosBias*SeqBias
        else:
          TotalBias = np.ones((geneLen,Lane))

        currentPath = os.getcwd()
        targetDir = os.path.join(currentPath,'Model.Data')
        targetDir = os.path.join(targetDir,'Gene.Bias')
        targetFile = os.path.join(targetDir,geneName)

        if EffLen>=50:
          f_out=open(targetFile,'w')
          for i in range(EffLen):
              for j in range(Lane):
                  f_out.write(str(round(TotalBias[i,j],6))+'\t')
              f_out.write('\n')
          f_out.close()
        else:
          f_out=open(targetFile,'w')
          for i in range(geneLen):
              for j in range(Lane):
                  f_out.write(str(round(TotalBias[i,j],6))+'\t')
              f_out.write('\n')
          f_out.close()
         
