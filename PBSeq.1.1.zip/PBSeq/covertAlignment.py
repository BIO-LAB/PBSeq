#! /usr/bin/env python

import pp
import os

def covertAlignment(AnnotationType,AlignmentPaths,AlignmentNames,InputName):

	targetDir = os.getcwd()
	referenceDir = os.path.join(targetDir,'Annotation')
	referenceFile = os.path.join(referenceDir,InputName+'.Gene.Label.Isoform')

	f = open(referenceFile,'r')
	DictRef ={}
	for line in f:
		line = line.rstrip()
		line = line.split('\t')
		gene = line[0]
		trans = line[2].rstrip()
		DictRef[trans] = gene
	f.close()


	job_server = pp.Server()
	job_server.get_ncpus()
	# job_server.set_ncpus(2)

	jobs =[]
	covertDataPath = []
	for index in xrange(len(AlignmentPaths)):
		alignPath = AlignmentPaths[index]
		alignName = AlignmentNames[index]

		outputDir = os.path.join(targetDir,'Model.Temp')
		outputDir = os.path.join(outputDir,alignName)
		outputDir = os.path.join(outputDir,'Data.Covert')
		outputFile = os.path.join(outputDir,alignName)

		covertDataPath.append(outputFile)

		jobs.append(job_server.submit(covert,(AnnotationType,alignPath,outputFile,DictRef,),globals=globals()))
 

	for job in jobs:
		job()

	jobs_uniq = []
	for index in xrange(len(covertDataPath)):
		InputFile = covertDataPath[index]
		jobs_uniq.append(job_server.submit(extractUniq,(InputFile,),globals=globals()))


	for job in jobs_uniq:
		job()




def covert(AnnotationType,InputFile,OutputFile,DictRef):
	f = open(InputFile,'r')
	fo = open(OutputFile+'.covert','w')
	for line in f:
		line = line.rstrip()
		line = line.split('\t')
		read = line[0]
		trans = line[1]
		loc = line[2]
		seq = line[3]

		# trans = trans.split('_')
		# if len(trans)==1:                   # using annotation from Ensembl
		# 	trans = trans[0]
		# else:                               # using annotation from UCSC
		# 	trans = trans[2]+'_'+trans[3]

		# # print trans


		trans = trans.split('_')
		if AnnotationType in ["Ensembl"]:                   # using annotation from Ensembl
			trans = trans[0]
		elif AnnotationType in ["knownGene",'ensGene']:
			trans = trans[2]
		elif AnnotationType in ["refGene"]:                               # using annotation from UCSC
			trans = trans[2]+'_'+trans[3]

		if trans in DictRef:
			gene = DictRef[trans]
			gene = gene
			fo.write(read+'\t'+loc+'\t'+trans+'\t'+gene+'\t'+seq+'\n')
		else:
			pass

	f.close()
	fo.close()

def extractUniq(InputFile):

	DictReadNo ={}
	f = open(InputFile+'.covert','r')
	for line in f:
		line = line.rstrip()
		line = line.split('\t')
		read = line[0]

		if read not in DictReadNo:
			DictReadNo[read] = 1
		else:
			DictReadNo[read] = DictReadNo[read]+1
	f.close()
	
	DictUniq = {}
	for key,value in DictReadNo.iteritems():
		if value == 1:
			DictUniq[key] = value
		else:
			pass
	del DictReadNo


	f = open(InputFile+'.covert','r')
	fo = open(InputFile+'.uniq','w')
	for line in f:
		line = line.rstrip()
		line = line.split('\t')
		read,loc,trans,gene,seq = line

		if read in DictUniq:
			fo.write(read+'\t'+loc+'\t'+trans+'\t'+gene+'\t'+seq+'\n')
		else:
			pass
	f.close()
	fo.close()



