#! /usr/bin bash 

time python ./PBSeq/preprocessAnnotation.py  -a ensGene.chr1.txt -o ensGene.chr1 -s ensGene.chr1.ref_transcript.fa 

time python ./PBSeq/preprocessAlignment.py -a ./Data.Bowtie/Cond.1.Lane.1.output,Cond.1.Lane.2.output  -i ensGene.chr1
