/* **************************************************************************** */
/*        pbseq C implementation                                          */
/* **************************************************************************** */
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include "o8para.h"
#include "calculateExpression.h"
#include "constants.h"

#include <malloc.h>

static expparam in_param;            
void donlp2(void);

typedef void (*func_void_void_t)(void);
typedef void (*func_void_type_liste_donlp_x_err_t)(IINTEGER type, IINTEGER liste[],
				DDOUBLE donlp2_x[], DDOUBLE con[], LLOGICAL err[]);
typedef void (*func_void_liste_shift_donlp_x_grad_t)(IINTEGER liste[], IINTEGER shift ,
				DDOUBLE donlp2_x[], DDOUBLE **grad);
typedef void (*func_void_donlp_x_fx_t)(DDOUBLE donlp2_x[],DDOUBLE *fx);
typedef void (*func_void_donlp_x_gradf_t)(DDOUBLE donlp2_x[],DDOUBLE gradf[]);
typedef void (*func_void_mode_t)(IINTEGER mode);
typedef void (*func_void_t)();

extern func_void_type_liste_donlp_x_err_t econ;
extern func_void_liste_shift_donlp_x_grad_t econgrad;
extern func_void_donlp_x_fx_t ef;
extern func_void_donlp_x_gradf_t egradf;
extern func_void_mode_t eval_extern;
extern func_void_t freemem;
extern func_void_t initialparams;
extern func_void_void_t setup;
extern func_void_void_t solchk;
extern func_void_void_t user_init;
extern func_void_void_t user_init_size;
extern func_void_t allocatemem;

void econ_pbseq(IINTEGER type, IINTEGER liste[],DDOUBLE donlp2_x[], DDOUBLE con[], LLOGICAL err[]);
void econgrad_pbseq(IINTEGER liste[], IINTEGER shift ,DDOUBLE donlp2_x[], DDOUBLE **grad);
void ef_pbseq(DDOUBLE donlp2_x[],DDOUBLE *fx);
void egradf_pbseq(DDOUBLE donlp2_x[],DDOUBLE gradf[]);
void eval_extern_pbseq(IINTEGER mode);
void setup_pbseq();
void solchk_pbseq();
void user_init_pbseq(void);
void user_init_size_pbseq(void);
void initialparams_pbseq();
void allocatemem_pbseq();
void freemem_pbseq();

//* Copyright (c) 1995-2004 by Radford M. Neal   


	
void initialparams_pbseq()
{

	//in_param.parameters=NULL;

	econ = econ_pbseq;
	econgrad = econgrad_pbseq;
	ef = ef_pbseq;
	egradf = egradf_pbseq;
	eval_extern = eval_extern_pbseq;
	//freemem = freemem_pbseq;
	initialparams = initialparams_pbseq;
	setup = setup_pbseq;
	solchk = solchk_pbseq;
	user_init = user_init_pbseq;
	user_init_size = user_init_size_pbseq;
	allocatemem = allocatemem_pbseq;
	
	//printf("initialparams_pbseq()\n");
}
	
void allocatemem_pbseq()
{
	int i;

	// in_param.parameters=(double *)malloc(sizeof(double) * (in_param.AlphaNo) );
	for(i=0;i<in_param.AlphaNo;i++)
		in_param.parameters[i]=0.0;

	for(i=0;i<in_param.IsoNo+2;i++){
		in_param.output[i]=0.0;
      } 
	//printf("allocatemem_pbseq()\n");	
}

// void freemem_pbseq(double* p)
// {	
	
// 	free(p);
// 	//printf("freemem_pbseq()\n");
// }

	
void getData(char *GeneDataP,char *GeneMapP,char *GeneBiasP,int isoNo,int geneLen,int repNo, int repInd, double NormConst)//outputpath,pwd
{	
	int i,j;


	
	FILE *fData,*fMap,*fBias;   
	fData=fopen(GeneDataP,"r");
	fMap=fopen(GeneMapP,"r");
	fBias=fopen(GeneBiasP,"r");
	
	in_param.IsoNo= isoNo;
	in_param.GeneLen = geneLen;
	in_param.RepNo = repNo;
	in_param.RepInd = repInd;
	in_param.NormConst = NormConst;



	double GeneData[in_param.GeneLen][in_param.RepNo];
	double GeneBias[in_param.GeneLen][in_param.RepNo];

	in_param.AlphaNo = in_param.IsoNo;
	
	if(fData==NULL||fMap==NULL||fBias==NULL)
	{
		printf("can not open!");
	}
	
	for(i=0;i<in_param.GeneLen;i++)
		for(j=0;j<in_param.IsoNo;j++)
		    in_param.GeneMap[i][j]=0.0; 

	for(i=0;i<in_param.GeneLen;i++)
		for(j=0;j<in_param.IsoNo;j++)
		fscanf(fMap,"%lf",&in_param.GeneMap[i][j]);					



	for(i=0; i<in_param.GeneLen;i++)
		for(j=0;j<in_param.RepNo;j++)
		     GeneData[i][j]=0.0;

	for(i=0; i<in_param.GeneLen;i++)
	     for(j=0;j<in_param.RepNo;j++)
		  fscanf(fData,"%lf",&GeneData[i][j]);

	for(i=0; i<in_param.GeneLen;i++)
		in_param.GeneData[i]=GeneData[i][in_param.RepInd];



	for(i=0;i<in_param.GeneLen;i++)
		for(j=0;j<in_param.RepNo;j++)
		        GeneBias[i][j]=0.0;	

	for(i=0; i<in_param.GeneLen;i++)
	     for(j=0;j<in_param.RepNo;j++)
		  fscanf(fBias,"%lf",&GeneBias[i][j]);
		
	for(i=0; i<in_param.GeneLen;i++)
	    in_param.GeneBias[i]=GeneBias[i][in_param.RepInd]/1000;



	fclose(fData);
	fclose(fMap);
	fclose(fBias);

	return;

}



void calcExpression(){   
   int i,j;
   double AlphaSum,temp;
   double sigma[MAX_NUM_IsoNo]={0.0},grad[MAX_NUM_IsoNo]={0.0};
   double mapvar[MAX_NUM_IsoNo]={0.0},mapmean[MAX_NUM_IsoNo]={0.0};




   for(i=0;i<in_param.GeneLen;i++)
   {
   	   AlphaSum = 0.0;
   	   for(j=0;j<in_param.IsoNo;j++)
          AlphaSum += in_param.GeneMap[i][j]*in_param.parameters[j];



       for(j=0;j<in_param.IsoNo;j++){
       	        temp=0;
       	  temp =  in_param.NormConst*in_param.GeneBias[i]*in_param.GeneMap[i][j];
      	  sigma[j] += temp/AlphaSum;
          grad[j] += in_param.GeneData[i]*in_param.GeneMap[i][j]/AlphaSum-temp;
       }
   }






   for(i=0;i<in_param.IsoNo;i++){   
        mapvar[i] = 1.0/sigma[i];
        mapmean[i] = mapvar[i]*grad[i]+in_param.parameters[i];



   }


  double truncmean[MAX_NUM_IsoNo]={0.0},truncvar[MAX_NUM_IsoNo]={0.0};
  double cont,tempx,tempxx;

  for(i=0;i<in_param.IsoNo;i++){

  	tempx = sqrt(mapvar[i]/(2*M_PI))*exp(-(mapmean[i]*mapmean[i])/(2*mapvar[i]));
  	tempxx = 1+erf(mapmean[i]/sqrt(2*mapvar[i]));
  	cont = 2/tempxx;

  	truncmean[i]=cont*(tempx+(mapmean[i]/2)*tempxx);
  	truncvar[i] = mapvar[i]-(truncmean[i]-mapmean[i])*(truncmean[i]-mapmean[i])-mapmean[i]*(truncmean[i]-mapmean[i]);



    if(fpclassify(cont)==FP_INFINITE||truncmean[i]<0||truncvar[i]<0){
       truncmean[i] = in_param.parameters[i];
       truncvar[i] = mapvar[i];

}
    
     }







     double transLen[MAX_NUM_IsoNo]={0.0};
     for(i=0;i<in_param.GeneLen;i++)
     	for(j=0;j<in_param.IsoNo;j++)
     	    transLen[j] +=in_param.GeneMap[i][j];

     double transMean[MAX_NUM_IsoNo]={0.0},transVar[MAX_NUM_IsoNo]={0.0};
     for(i=0;i<in_param.IsoNo;i++)
     {
     	transMean[i]= truncmean[i];
     	transVar[i] = transLen[i]*truncvar[i]/1000;

     }
   
     double geneMean=0.0,geneVar=0.0;
     for(i=0;i<in_param.IsoNo;i++)
         {
         	geneMean += truncmean[i];
         	geneVar += truncvar[i];
         }
     geneVar = in_param.GeneLen*geneVar/1000;
    


   in_param.output[0]=geneMean;
   in_param.output[1]=geneVar;
  for(i=0;i<in_param.IsoNo;i++){
  	in_param.output[i+2] = transMean[i];
  	in_param.output[i+in_param.IsoNo+2] = transVar[i];          
     }


    return;

}


double* calparameters(int  isoNo) 
{
    #define  X extern
    #include "o8comm.h"
    #undef   X
    #include "o8cons.h"

	int i;	
	double *parameters;                        
	
	initialparams_pbseq();
	allocatemem_pbseq();


	donlp2();

 calcExpression();


      parameters=(double *)malloc(sizeof(double) * (2*in_param.IsoNo+2));
     	for(i=0;i<2*in_param.IsoNo+2;i++)
		    parameters[i]= 0.0;


      	for(i=0;i<2*in_param.IsoNo+2;i++)
		    parameters[i]= in_param.output[i];



	return parameters;



}



/* **************************************************************************** */
/*                                 special setup                                */
/* **************************************************************************** */
void setup_pbseq(void) {
    #define  X extern
    #include "o8comm.h"
    #undef   X
   
  // printf("setup_pbseq\n");
    return;
}

/* **************************************************************************** */
/*  the user may add additional computations using the computed solution here   */
/* **************************************************************************** */
void solchk_pbseq(void) {
    #define  X extern
    #include "o8comm.h"
    #undef   X
    #include "o8cons.h"
    
    int i;
    
    for(i=0;i<in_param.AlphaNo;i++)
    	in_param.parameters[i]=donlp2_x[i+1];

    return ;
}

/* **************************************************************************** */
/*                               objective function                             */
/* **************************************************************************** */
void ef_pbseq(DDOUBLE donlp2_x[],DDOUBLE *fx) {
    #define  X extern
    #include "o8fuco.h"
    #undef   X
    
    int i,j,k;
    double temp,AlphaSum;
    double alpha[in_param.AlphaNo];
	
    *fx=0.0;

    for(i=0;i<in_param.AlphaNo;i++)
    	alpha[i] = donlp2_x[i+1];

    for(i=0;i<in_param.GeneLen;i++){

    	AlphaSum = 0.0;
    	for(j=0;j<in_param.AlphaNo;j++)
    		AlphaSum += in_param.GeneMap[i][j]*alpha[j];

    	temp = in_param.NormConst*in_param.GeneBias[i]*AlphaSum;

    	*fx = *fx + in_param.GeneData[i]*log(AlphaSum) - temp;

    }



   
	*fx = -*fx;


    return;
}


/* **************************************************************************** */
/*                          gradient of objective function                      */
/* **************************************************************************** */
void egradf_pbseq(DDOUBLE donlp2_x[],DDOUBLE gradf[]) { 

    #define  X extern
    #include "o8fuco.h"
    #undef   X
    
    int i,j,k;
    double AlphaSum;
    double alpha[in_param.AlphaNo];

	for(i=0;i<in_param.AlphaNo;i++)
    	gradf[i+1] =0.0;

    for(i=0;i<in_param.AlphaNo;i++)
    	alpha[i] = donlp2_x[i+1];


    for(i=0;i<in_param.GeneLen;i++){
     	AlphaSum = 0.0;
    	for(j=0;j<in_param.AlphaNo;j++)
    		AlphaSum+= in_param.GeneMap[i][j]*alpha[j];	
 	

        for(j=0;j<in_param.AlphaNo;j++){
         	gradf[j+1]+=(0.0+in_param.GeneData[i]*in_param.GeneMap[i][j])/AlphaSum -in_param.NormConst*in_param.GeneBias[i]*in_param.GeneMap[i][j];
    	}
    }

	for (i=0; i<in_param.AlphaNo; i++)
	  {
	  	 gradf[i+1] = -gradf[i+1];
	  }
	
      return;
}

/* **************************************************************************** */
/*                              donlp2-intv size initialization                           */
/* **************************************************************************** */
void user_init_size_pbseq(void) {

    #define  X extern
    #include "o8comm.h"
    #include "o8fint.h"
    #include "o8cons.h"
    #undef   X

    n = in_param.AlphaNo;  
	nstep = 40;
    
    nlin   =  0;
    nonlin =  0;
    iterma = 4000;
}

/* **************************************************************************** */
/*                              donlp2 standard setup                           */
/* **************************************************************************** */
void user_init_pbseq(void) {

    #define  X extern
    #include "o8comm.h"
    #include "o8fint.h"
    #include "o8cons.h"
    #undef   X    

    int i,j;
    silent = 1;
    big = 1.e18;
 
	/* initialise the parameters */
	for (i=1; i<=in_param.AlphaNo; i++)
	{	
		donlp2_x[i] = 2.0;
		low[i] = ALOW;
		up[i] = big;	
	}
	

    
    analyt = 1;
    epsdif = 1.e-16;  
   
    nreset = n; 
    del0 = 1.0e0;
    tau0 = 1.0e1;
    tau  = 0.1e0;
    
    return;
}
/* **************************************************************************** */
/*                        no nonlinear constraints                              */
/* **************************************************************************** */
void econ_pbseq(IINTEGER type, IINTEGER liste[], DDOUBLE donlp2_x[], DDOUBLE con[],LLOGICAL err[]) {
             
    #define  X extern
    #include "o8fuco.h"
    #undef   X

    return;
}

/* **************************************************************************** */
/* **************************************************************************** */
void econgrad_pbseq(IINTEGER liste[], IINTEGER shift ,  DDOUBLE donlp2_x[], DDOUBLE **grad) {
              
    #define  X extern
    #include "o8fuco.h"
    #undef   X
    return;
}


/* **************************************************************************** */
/*                        user functions (if bloc == TRUE)                      */
/* **************************************************************************** */
void eval_extern_pbseq(IINTEGER mode) {

    #define  X extern
    #include "o8comm.h"
    #include "o8fint.h"
    #undef   X
    #include "o8cons.h"

    return;
}

