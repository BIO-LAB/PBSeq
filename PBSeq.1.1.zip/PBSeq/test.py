#! /usr/bin/env python 

import os 
import sys, getopt
import pp
import example


def usage():
  print "Usage:"
  print "    calculateExpression -a Annotation_Name  -i TargetGene "
  print "options:"
  print '   -d/--AlignmentFiles    input one or a list of alignment files from Bowtie, eg: SRRXXX.output'
  print '   -a/--Annotation        the abbreviative name is same as the outputName of preprocessAnnotation, eg:ensGene'
  print '   -i/--InputGene         input gene'
  print '   -h/--help              display this help and exit'
  print '   -v/--version           output version information and exit\n'
  sys.exit(1)

def error(n):
  if n==1:
    print "Error: need input the correct parameters:  -a <string> OR  -a <string> -i <file> \n" 
  if n==2:
    print "Error: need input the complete parameters:  -a <string> OR  -a <string> -i <file>\n"


try:
    opts, args = getopt.getopt(sys.argv[1:], "hva:i:", ["help","version", "Annotation","InputGene",""])
except getopt.GetoptError:
    error(1)
    usage()
    sys.exit()


targetGene = 'default'
input_name = 'default'

for op, value in opts:
    if op in ["-a","--Annotation"]:
        input_name = value
    elif op in ['-i','--InputGene']:
      targetGene = value
    elif op in ["-v","--version"]:
        print 'The version of PBSeq is v0.1_alpha.'
        sys.exit()
    elif op in ["-h","--help"]:
        usage()        
        sys.exit()

if targetGene == 'default':                            # now, the targetGene will set 'default'
  currentPath = os.getcwd()
  targetDir = os.path.join(currentPath,'Annotation')
  targetGene = os.path.join(targetDir,input_name)
  targetGeneFile = targetGene+'.Gene.Info'  
else:
  targetGeneFile = targetGene

parametersList = [input_name,targetGeneFile]

if 'default' in parametersList:
    error(2)
    usage()
    sys.exit()
else:
    pass


f= open(targetGeneFile,'r')
geneNameList = []
isoNoList = []
for line in f:
    line = line.rstrip()
    line = line.split('\t')
    geneName = line[0]
    isoNo = int(line[1])

    geneNameList.append(geneName)
    isoNoList.append(isoNo)
f.close()



def calculateExpression(geneNameList,isoNoList):

  currentPath = os.getcwd()
  modelDataPath = os.path.join(currentPath,'Model.Data')


  for index in xrange(len(geneNameList)):
    geneName = geneNameList[index]
    isoNo = int(isoNoList[index])

    geneDataPath = os.path.join(modelDataPath,'Gene.Data')
    geneDataFile = os.path.join(geneDataPath,geneName)

    geneMapPath = os.path.join(modelDataPath,'Gene.Map')
    geneMapFile = os.path.join(geneMapPath,geneName)

    geneBiasPath = os.path.join(modelDataPath,'Gene.Bias')
    geneBiasFile = os.path.join(geneBiasPath,geneName)

    geneResultPath = os.path.join(modelDataPath,'Result')
    geneResultFile = os.path.join(geneResultPath,geneName)




    f = open(geneDataFile,'r')
    Data = [line.rstrip()  for line in f.readlines()]
    Data = [line.split('\t') for line in Data]
    f.close()

    print geneDataFile,geneMapFile,geneBiasFile

    geneLen = len(Data)
    repNo = len(Data[0])

    example.getData(geneDataFile,geneMapFile,geneBiasFile,isoNo,geneLen,repNo)
     # calculateExpression.poga_calparameters(geneResultFile)



    repInd = 1
    for repInd in xrange(repNo):
      # print geneName,isoNo,geneLen,repNo,repInd   
      example.getData(geneDataFile,geneMapFile,geneBiasFile,isoNo,geneLen,repNo,repInd)
    # example.calparameters(geneResultFile)



parts = 32
start = 0 
end = len(geneNameList)
step = end/parts+1

job_server = pp.Server()
# job_server.get_ncpus()
job_server.set_ncpus(1)

jobs = []

for index in xrange(parts):
    starti = start+index*step
    endi = min(start+(index+1)*step,end)
    geneNamei = geneNameList[starti:endi]
    isoNoi = isoNoList[starti:endi]
    jobs.append(job_server.submit(calculateExpression,(geneNamei,isoNoi,),modules=('os',),globals=globals()))

for job in jobs:
  job()

