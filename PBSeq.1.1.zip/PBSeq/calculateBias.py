#! /usr/bin/env python
# -*- coding: utf-8 -*-
# from __future__ import division
# 计算序列特性的偏差。
# 我们这里对于读段起始位置在8以内的不予统计，直接丢弃。这种读段的比率非常小，0.2%。
import os
import numpy as np
import pp
import calculateDataBias


def calculateLaneDataBias(InputData,OutputFile,InputName):
    # print 'Pre-processing Sequence File.'
    currentDir = os.getcwd()
    referenceDir = os.path.join(currentDir,'Annotation')
    referenceDir = os.path.join(referenceDir,InputName)
    referenceFile = referenceDir+'.Gene.SingleTrans.Sequence.fa'


    f = open(referenceFile,'r')
    Dict_Seq = {}
    Dict_Vect = {}
    for line in f:
        line = line.rstrip()
        line = line.split('\t')
        Gene,Trans,Len,Seq = line
        Gene = Gene.strip()  
        Dict_Seq[Gene] = Trans,Gene,Len,Seq
        Dict_Vect[Gene] = np.zeros(int(Len))
    f.close()

    # print 'Pre-processing Alignments File.'
    f = open(InputData,'r')
    for line in f:
        line = line.rstrip()
        line = line.split('\t')
        Read,Loc,Trans,Gene,Seq = line
        Loc = int(Loc)
        # Gene = Gene.strip()

        if Gene in Dict_Seq:
              Vect = Dict_Vect[Gene]
              Vect[Loc] = Vect[Loc]+1
              Dict_Vect[Gene] = Vect      
        else:
           pass
    f.close()

    ReadLen = len(Seq)


    Dict_Value = Dict_Vect.items()
    ValidGene = []
    for i in range(len(Dict_Value)):
        line = Dict_Value[i]
        Gene = line[0].strip()
        Count = line[1]
        if sum(Count)!=0:
            ValidGene.append(Gene)
    # print 'Valid Gene: ',len(ValidGene)



    # print 'Calculating Position Bias.'
    calculateDataBias.PositionBias(ValidGene,Dict_Seq,Dict_Vect,OutputFile,ReadLen)
    # print 'Calculating Sequence Bias.'
    calculateDataBias.SequenceBias(ValidGene,Dict_Seq,Dict_Vect,OutputFile,ReadLen)



def calculateBias(AlignmentName,InputName,targetGeneFile):
    targetDir = os.getcwd()

    job_server = pp.Server()
    job_server.get_ncpus()
    # job_server.set_ncpus(2)
    jobs =[]
    outputFileList = []
    for index in xrange(len(AlignmentName)):
        alignName = AlignmentName[index]

        inputDir = os.path.join(targetDir,'Model.Temp')
        inputDir = os.path.join(inputDir,alignName)
        inputDir = os.path.join(inputDir,'Data.Covert')
        inputFile = os.path.join(inputDir,alignName)
        inputFile = inputFile+'.uniq'

        outputDir = os.path.join(targetDir,'Model.Temp')
        outputDir = os.path.join(outputDir,alignName)
        outputDir = os.path.join(outputDir,'Data.Bias')
        outputFile = os.path.join(outputDir,alignName)

        outputFileList.append(outputFile)

        jobs.append(job_server.submit(calculateLaneDataBias,(inputFile,outputFile,InputName),modules=('numpy as np','calculateDataBias',),globals=globals()))


    for job in jobs:
        job() 

    # print 'Pre-processing Alignments File.'
    f = open(inputFile,'r')
    line = f.readline()
    f.close()
    line = line.rstrip()
    line = line.split('\t')
    Read,Loc,Trans,Gene,Seq = line
    ReadLen = len(Seq)   


    ColNo = len(AlignmentName)
    PosBias = np.zeros(100*ColNo).reshape(100,ColNo)
    SeqBias = np.zeros(744*ColNo).reshape(744,ColNo)
    col = 0 

    for index in xrange(len(AlignmentName)):
        outputFile = outputFileList[index]
        InputPoiBiasDat = outputFile+'.PosBias'
        PosBias[:,col] = calculateDataBias.PosBiasProb(InputPoiBiasDat)
        InputSeqBiasData = outputFile+'.SeqBias'
        SeqBias[:,col]=calculateDataBias.SeqBiasProb(InputSeqBiasData,'Base')        
        col = col+1


    outputDir = os.path.join(targetDir,'Model.Temp')


    f = open(InputPoiBiasDat,'r')
    lineNo = 0
    Dict_PosBias ={}
    for line in f:
        line = line.rstrip()
        line = line.split('\t')
        Group = line[0]
        Bin = line[1]
        Ind = Group+'.'+Bin
        Bias = PosBias[lineNo,:]
        Dict_PosBias[Ind] = Bias
        lineNo = lineNo+1
    f.close()

    f = open(InputSeqBiasData,'r')
    lineNo = 0
    Dict_SeqBias = {}
    for line in f:
        line = line.rstrip()
        line = line.split('\t')
        Loc = line[0]
        Base = line[1]
        Ind = Loc+'.'+Base
        Bias = SeqBias[lineNo,:]
        Dict_SeqBias[Ind] = Bias
        lineNo = lineNo+1       
    f.close()


                 

    f_in = open(targetGeneFile,'r')                   # targetGeneFile  
    DataTemp = [line.strip() for line in f_in.readlines()];
    DataTemp = [line.split('\t') for line in DataTemp];
    GeneNameList = [line[0] for line in DataTemp]
    f_in.close()   
    del DataTemp


    currentDir = os.getcwd()
    referenceDir = os.path.join(currentDir,'Annotation')
    referenceDir = os.path.join(referenceDir,InputName)
    referenceFile = referenceDir+'.Gene.Sequence.fa'

    Dict_GeneSeq = {}
    f = open(referenceFile,'r')
    for line in f:
        line = line.rstrip()
        line = line.split('\t')
        geneName, isoNo, geneLen, geneSeq = line
        Dict_GeneSeq[geneName] = geneSeq 
    f.close()

    parts = 32
    start = 0 
    end = len(GeneNameList)
    step = end/parts+1

    jobs_bias = [] 

    for index in xrange(parts):
        starti = start+index*step
        endi = min(start+(index+1)*step,end)
        GeneNamei = GeneNameList[starti:endi]

        Dict_GeneSeqi = {}
        for geneNameIndex in xrange(len(GeneNamei)):
            geneName = GeneNamei[geneNameIndex]#.strip()
            geneSeq = Dict_GeneSeq[geneName]
            Dict_GeneSeqi[geneName] = geneSeq

        jobs_bias.append(job_server.submit(calculateDataBias.ExtractGeneBias,(Dict_GeneSeqi,Dict_PosBias,Dict_SeqBias,ReadLen,len(AlignmentName),),modules=('os','numpy as np','calculateDataBias',),globals=globals()))

    del Dict_GeneSeq

    for job in jobs_bias:
        job()






